# Typing.com Hack Bot - For Lazy People
Typing Bot for Typing.com that completes your lessons and tests automatically.
![Image of Typing.com Bot](https://raw.githubusercontent.com/PrabhakarRai/Typing-com-hack-bot/master/typing-com-bot.png)

## [Get it From Madcap Hacker](https://www.theprabhakar.in)
